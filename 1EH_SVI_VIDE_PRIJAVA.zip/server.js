const express=require('express');
const multer=require('multer');
const fs=require('fs'); const path=require('path'); const crypto=require('crypto');
const Database=require('better-sqlite3');
const app=express(); const PORT=process.env.PORT||3000; const ROOT=__dirname, PUB=path.join(ROOT,'public'), UP=path.join(PUB,'uploads');
fs.mkdirSync(UP,{recursive:true});
const db=new Database(path.join(ROOT,'data.db'));
db.exec(`CREATE TABLE IF NOT EXISTS content(key TEXT PRIMARY KEY,value TEXT NOT NULL);`);
const defaults={intro:'1.EH je mali razred s 9 učenika cvjećara i poljoprivrednih gospodarstvenika.',rules:JSON.stringify(['Poštujmo jedni druge.','Poštujmo učitelje.','Budimo uvijek dobre volje.']),hw:'[]',news:'[]',scheduleE:'',scheduleH:''};
for(const [k,v] of Object.entries(defaults)) db.prepare('INSERT OR IGNORE INTO content(key,value) VALUES(?,?)').run(k,v);
app.use(express.json({limit:'2mb'}));
const upload=multer({dest:path.join(ROOT,'tmp'),limits:{fileSize:20*1024*1024},fileFilter:(req,f,cb)=>/^image\/(jpeg|png|webp|gif)$/.test(f.mimetype)?cb(null,true):cb(new Error('Dopuštene su samo slike JPG, PNG, WEBP ili GIF.'))});
fs.mkdirSync(path.join(ROOT,'tmp'),{recursive:true});
const sessions=new Map();
function isAdmin(req){const t=req.headers['x-admin-token']; return !!t&&sessions.has(t);}
function read(){const rows=db.prepare('SELECT key,value FROM content').all();const o=Object.fromEntries(rows.map(r=>[r.key,r.value]));for(const k of ['rules','hw','news']){try{o[k]=JSON.parse(o[k]||'[]')}catch{o[k]=[]}}return o;}
app.get('/api/data',(req,res)=>res.json(read()));
app.post('/api/login',(req,res)=>{if(req.body.username==='admin'&&req.body.password==='567'){const token=crypto.randomBytes(32).toString('hex');sessions.set(token,Date.now());res.json({ok:true,token});}else res.status(401).json({error:'Pogrešno korisničko ime ili zaporka.'});});
app.post('/api/logout',(req,res)=>{sessions.delete(req.headers['x-admin-token']);res.json({ok:true});});
app.post('/api/content',(req,res)=>{if(!isAdmin(req))return res.status(401).json({error:'Nisi prijavljen kao admin.'});for(const k of ['intro','rules','hw','news']){let v=req.body[k];if(k==='rules'||k==='hw'||k==='news')v=JSON.stringify(Array.isArray(v)?v:[]);if(typeof v==='string')db.prepare('UPDATE content SET value=? WHERE key=?').run(v,k);}res.json(read());});
app.post('/api/schedule',upload.fields([{name:'scheduleE',maxCount:1},{name:'scheduleH',maxCount:1}]),(req,res)=>{if(!isAdmin(req))return res.status(401).json({error:'Nisi prijavljen kao admin.'});for(const key of ['scheduleE','scheduleH']){const f=req.files?.[key]?.[0];if(!f)continue;const ext=path.extname(f.originalname).toLowerCase()||'.jpg';const final=key+ext;for(const e of ['.jpg','.jpeg','.png','.webp','.gif']){const old=path.join(UP,key+e);if(fs.existsSync(old))fs.unlinkSync(old);}fs.renameSync(f.path,path.join(UP,final));db.prepare('UPDATE content SET value=? WHERE key=?').run('/uploads/'+final,'schedule'+key);}res.json(read());});
app.use('/uploads',express.static(UP));app.use(express.static(PUB));
app.use((err,req,res,next)=>res.status(400).json({error:err.message||'Greška.'}));
app.listen(PORT,()=>console.log('1.EH server radi na portu '+PORT));
