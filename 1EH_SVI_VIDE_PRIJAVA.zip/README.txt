1.EH – ISTA STRANICA, ZAJEDNIČKI PODACI

Ovo je ista verzija stranice kao prethodna radna verzija, ali više NE sprema sadržaj u localStorage/IndexedDB.
Sadržaj i rasporedi spremaju se na server, pa svi uređaji koji otvore istu online adresu vide iste podatke.

ADMIN
Korisničko ime: admin
Lozinka: 567

RASPORED
1.E i 1.H mogu se dodati jednim gumbom.
Maksimalna veličina: 20 MB po slici.

VAŽNO
ZIP sam po sebi nije javna web-stranica. Ovaj paket treba pokrenuti na Node.js hostingu/serveru.
Za trajno spremanje mora biti omogućen trajni disk za data.db i public/uploads.

LOKALNO
npm install
npm start
zatim otvoriti http://localhost:3000

ZA SVE UČENIKE
Kad se projekt objavi na hostingu i dobije javnu HTTPS adresu, svi učenici otvaraju TU ISTU adresu. Adminove promjene tada su zajedničke.
